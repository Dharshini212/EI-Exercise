public interface DeviceObserver {
    void update(Device device);
}
